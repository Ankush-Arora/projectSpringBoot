package com.loan.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="LOANDETAIL")
public class NewLoan {

	@Id
	private int loanNumber;
	private String firstName;
	private String lastName;
	private String address;
	private int loanAmount;
	private String loanType;
}
