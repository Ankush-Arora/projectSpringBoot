package com.loan.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.loan.entity.NewLoan;
import com.loan.entity.SearchLoan;
import com.loan.repository.NewLoanRepository;

@Service
public class NewLoanService {

	@Autowired
	private NewLoanRepository newLoanRepository;

	public void initNewLoan() {
		NewLoan loan1 = new NewLoan();
		loan1.setLoanNumber(123);
		loan1.setFirstName("ankush");
		loan1.setLastName("arora");
		loan1.setAddress("123 dehradun");
		loan1.setLoanType("Education Loan");
		loan1.setLoanAmount(200000);
		newLoanRepository.save(loan1);

		NewLoan loan2 = new NewLoan();
		loan2.setLoanNumber(456);
		loan2.setFirstName("sharmila");
		loan2.setLastName("m");
		loan2.setAddress("567 chennai");
		loan2.setLoanType("Business Loan");
		loan2.setLoanAmount(300000);
		newLoanRepository.save(loan2);
	}

	public List<NewLoan> getAllLoansDetails() {
		List<NewLoan> userList = newLoanRepository.findAll();

		if (userList.size() > 0) {
			return userList;
		} else {
			return new ArrayList<NewLoan>();
		}
	}
	
	public void deleteStudent(int loanNumber)
	{
		newLoanRepository.deleteById(loanNumber);
	}

//	public NewLoan loanIsPresentOrNot(SearchLoan searchLoan) {
//		List<NewLoan> userList = newLoanRepository.findAll();
//		for (NewLoan each : userList) {
//			if (each.getFirstName().equals(searchLoan.getFirstName())
//					&& each.getLastName().equals(searchLoan.getLastName())
//					&& each.getLoanNumber() == searchLoan.getLoanNumber()) {
//				return each;
//			}
//		}
//		return null;
//	}
	
	public NewLoan loanIsPresentOrNot(int loanNumber) {
		List<NewLoan> userList = newLoanRepository.findAll();
		for (NewLoan each : userList) {
			if (  each.getLoanNumber() == loanNumber) {
				return each;
			}
		}
		return null;
	}
	
	public NewLoan updateStudent(NewLoan newLoan)
	{
		Integer loanId=newLoan.getLoanNumber();
		NewLoan std=newLoanRepository.findById(loanId).get();
		std.setFirstName(newLoan.getFirstName());
		std.setLastName(newLoan.getLastName());
		std.setAddress(newLoan.getAddress());
		std.setLoanAmount(newLoan.getLoanAmount());
		std.setLoanType(newLoan.getLoanType());
		
		return newLoanRepository.save(std);
	}

	public NewLoan addnewLoanDetails(NewLoan newLoan) {
		newLoanRepository.save(newLoan);
		return newLoan;
	}

}
