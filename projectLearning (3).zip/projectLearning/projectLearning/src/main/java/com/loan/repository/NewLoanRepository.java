package com.loan.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.loan.entity.NewLoan;

public interface NewLoanRepository extends JpaRepository<NewLoan, Integer>{

}
