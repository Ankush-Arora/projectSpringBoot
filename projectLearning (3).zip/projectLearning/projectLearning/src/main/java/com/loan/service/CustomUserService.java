package com.loan.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.loan.entity.User;
import com.loan.repository.UserRepository;

@Service
public class CustomUserService  implements UserDetailsService
{
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	 
	public User addNewUser(User user)
	{
		user.setPassword(this.bCryptPasswordEncoder.encode(user.getPassword()));
		userRepository.save(user);
		return user;
	}
	
	 
	public void initUsers()
	{
		User data=new User();
		data.setId(1);
		data.setUserName("ankush");
		data.setPassword(this.bCryptPasswordEncoder.encode("ankush123"));
		userRepository.save(data);
		
		User data1=new User();
		data1.setId(2);
		data1.setUserName("sharmila");
		data1.setPassword(this.bCryptPasswordEncoder.encode("sharmila123"));
		userRepository.save(data1);
		
	}

	 public List<User> getAllUsersDetails()
	    {
	        List<User> userList = userRepository.findAll();
	         
	        if(userList.size() > 0) {
	            return userList;
	        } else {
	            return new ArrayList<User>();
	        }
	    }
	
	 public User getEmployeeById(Integer id)  
	    {
	        Optional<User> employee = userRepository.findById(id);
	       
	        if(employee.isPresent()) {
	            return employee.get();
	        }
	        return null;

    }
	 
	 public User getAllUsers(String userName,String password)
	    {
	        List<User> employeeList = userRepository.findAll();
	        System.out.println("Name = "+userName);
	        System.out.println("Password = "+password);
	        for(User each: employeeList)
	        {
	        	if(each.getUserName().equals(userName) && each.getPassword().equals(password))
	        		{ 
	        		System.out.println("Id of emp = "+each.getId());
	        		return each;
	        		
	        		}
	        }
			return null;
	    }

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user=userRepository.findByUserName(username);
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), new ArrayList<>());
	}



}
