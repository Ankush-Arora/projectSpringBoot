package com.loan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
